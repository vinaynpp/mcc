# SAF_sample
Example of how to use Android Storage Access Framework for a basic use case. 
Please refer to this article: https://medium.com/@noldo.warrior/sample-for-android-storage-access-framework-aka-scoped-storage-for-basic-use-cases-3ee4fee404fc
